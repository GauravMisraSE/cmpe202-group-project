/**
 * Write a description of class ScoreObserver here.
 * 
 * @author Nitinkumar Gove 
 * @version 1.0
 */
public interface ScoreObserver  
{
    public  void updateScoreBoard();
}
