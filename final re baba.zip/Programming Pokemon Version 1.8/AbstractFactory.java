import greenfoot.*;
public abstract class AbstractFactory  
{
    abstract Actor getActor(String name);
}
