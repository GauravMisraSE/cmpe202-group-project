/**
 * Write a description of class ActorState here.
 * 
 * @author Sushant Vairagade 
 * @version 2016-11-18
 */
public interface ActorState  
{
    void move();
}
