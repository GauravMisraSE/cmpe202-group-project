public interface PokeSet1  
{
    void setGif();
}
