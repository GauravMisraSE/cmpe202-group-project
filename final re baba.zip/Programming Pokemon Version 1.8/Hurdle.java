/**
 * Write a description of intrface  Hurdle here.
 * 
 * @author Nitinkumar Gove
 * @version 1.0
 */
public interface Hurdle  
{
    public void  setAvatar();
}
