import greenfoot.*;

public class Platform extends Actor
{
    public void act() {}    
}