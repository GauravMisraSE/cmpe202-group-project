public class Wall extends Platform
{
    public void act() {}    
}